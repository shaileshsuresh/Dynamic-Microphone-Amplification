%%time = 0:2*pi;
plot(time,values);